# Cambios External iOS

- Se eliminó la pantalla de calculadora y su código de desbloqueo 052009.
- La pantalla de acceso ahora usa el diseño oscuro EXTERNAL - iOS, con campo Mostrar/Ocultar y botón Entrar.
- Todas las keys se validan en el servidor configurado. Ya no existe ninguna key de prueba local.
- El menú muestra los cuatro paquetes que documenta el proyecto: Head Avatar, Cuello Avatar, Pecho Avatar y Sintura Avatar.
- Los interruptores conservan la operación original del proyecto: aplicar el paquete .3105 o restaurar el cambio registrado. No son funciones de aimbot.
